NeqSim Python interface.  The python package py4j is used to connect python and java. Python toolboxes (thermoTools and processTools) are implemented to streamline use of neqsim in python. Examples of use are given in jupyter workbooks.

The neqsim package will be distributed as a pip package (neqsim).

Introduction to how to use neqsim in python are given in the Jupyter files.
