name = "neqsim"
from neqsim import javaGateway
javaGateway.startServer()
import time
time.sleep(5)
from neqsim.thermo.thermoTools import *
from neqsim.process.processTools import *